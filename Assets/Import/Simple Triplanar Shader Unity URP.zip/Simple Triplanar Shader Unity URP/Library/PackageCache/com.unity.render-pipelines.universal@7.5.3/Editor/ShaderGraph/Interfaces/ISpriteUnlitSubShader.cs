using UnityEditor.ShaderGraph;

namespace UnityEditor.Experimental.Rendering.Universal
{
    interface ISpriteUnlitSubShader : ISubShader
    {}
}
