Triplanar mapping Shader for Unity
==================================

This is a customized variant of Unity's standard shader with triplanar mapping
(texture mapping without UV coordinates).

![Screenshot](https://i.imgur.com/n5aKrlt.png)

License
-------

[Public domain](http://unlicense.org/)
